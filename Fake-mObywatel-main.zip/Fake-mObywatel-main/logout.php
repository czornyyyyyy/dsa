<?php
session_start();
session_unset();
session_destroy();
header("Location: index.php");
// This is made by Magiczny_Jasiek, and only he can sell it. If you bought it from other vacban.wtf listing that was not this one: https://vacban.wtf/vacshop/78615/ then be careful using it. It is not official.
?>
